import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Play, 
  Pause, 
  Activity,
  Monitor,
  Globe,
  Menu,
  X,
  RefreshCw
} from 'lucide-react'
import './App.css'

function App() {
  const [currentActivity, setCurrentActivity] = useState({
    browser: 'none',
    url: 'none', 
    title: 'none'
  })
  const [isTracking, setIsTracking] = useState(false)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [activityHistory, setActivityHistory] = useState([])

  useEffect(() => {
    // Listen for activity updates from main process
    const handleActivityUpdate = (activityData) => {
      setCurrentActivity(activityData)
      
      // Add to history (keep last 10 items)
      setActivityHistory(prev => {
        const newHistory = [
          { ...activityData, timestamp: new Date().toLocaleTimeString() },
          ...prev
        ].slice(0, 10)
        return newHistory
      })
    }

    // Setup IPC listener for activity updates
    if (window.electronAPI && window.electronAPI.onActivityUpdate) {
      window.electronAPI.onActivityUpdate(handleActivityUpdate)
    }

    return () => {
      // Cleanup if needed
    }
  }, [])

  const startTracking = async () => {
    try {
      if (window.electronAPI && window.electronAPI.startTracking) {
        await window.electronAPI.startTracking()
        setIsTracking(true)
      }
    } catch (error) {
      console.error('Failed to start tracking:', error)
    }
  }

  const stopTracking = async () => {
    try {
      if (window.electronAPI && window.electronAPI.stopTracking) {
        await window.electronAPI.stopTracking()
        setIsTracking(false)
      }
    } catch (error) {
      console.error('Failed to stop tracking:', error)
    }
  }

  const sidebarVariants = {
    expanded: { width: 280, opacity: 1 },
    collapsed: { width: 60, opacity: 0.9 }
  }

  const contentVariants = {
    expanded: { opacity: 1, x: 0 },
    collapsed: { opacity: 0, x: -20 }
  }

  return (
    <div className="app">
      {/* Animated Sidebar */}
      <motion.div 
        className="sidebar"
        variants={sidebarVariants}
        animate={sidebarCollapsed ? 'collapsed' : 'expanded'}
        transition={{ duration: 0.3, ease: 'easeInOut' }}
      >
        <div className="sidebar-header">
          <button 
            className="toggle-btn"
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          >
            {sidebarCollapsed ? <Menu size={20} /> : <X size={20} />}
          </button>

          <AnimatePresence>
            {!sidebarCollapsed && (
              <motion.div
                className="monitoring-controls"
                variants={contentVariants}
                initial="collapsed"
                animate="expanded"
                exit="collapsed"
                transition={{ duration: 0.3 }}
              >
                <h2>Browser Monitor</h2>
                
                <button 
                  className={`monitoring-btn ${isTracking ? 'active' : ''}`}
                  onClick={isTracking ? stopTracking : startTracking}
                >
                  {isTracking ? <Pause size={16} /> : <Play size={16} />}
                  {isTracking ? 'Stop Tracking' : 'Start Tracking'}
                </button>

                <div className="monitoring-status">
                  <div className="status-indicator">
                    <div className={`status-dot ${isTracking ? 'active' : 'inactive'}`}></div>
                    <span>{isTracking ? 'Active' : 'Inactive'}</span>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
      
      {/* Main Content */}
      <div className="main-content">
        <div className="content-header">
          <h1>
            <Activity size={24} />
            Browser Activity Monitor
          </h1>
        </div>

        <div className="content-area">
          {/* Current Activity Card */}
          <motion.div 
            className="activity-card current"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="card-header">
              <h3>
                <Globe size={18} />
                Current Activity
              </h3>
              <div className={`live-indicator ${isTracking ? 'active' : ''}`}>
                <div className="pulse-dot"></div>
                LIVE
              </div>
            </div>
            
            <div className="activity-details">
              <div className="detail-row">
                <span className="label">Browser:</span>
                <span className="value">{currentActivity.browser}</span>
              </div>
              <div className="detail-row">
                <span className="label">URL:</span>
                <span className="value url">{currentActivity.url}</span>
              </div>
              <div className="detail-row">
                <span className="label">Title:</span>
                <span className="value">{currentActivity.title}</span>
              </div>
            </div>
          </motion.div>

          {/* Activity History */}
          <motion.div 
            className="activity-card history"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <div className="card-header">
              <h3>
                <Monitor size={18} />
                Recent Activity
              </h3>
              <button className="refresh-btn">
                <RefreshCw size={16} />
              </button>
            </div>
            
            <div className="activity-timeline">
              <AnimatePresence>
                {activityHistory.length > 0 ? (
                  activityHistory.map((activity, index) => (
                    <motion.div
                      key={`${activity.timestamp}-${index}`}
                      className="timeline-item"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 20 }}
                      transition={{ duration: 0.3, delay: index * 0.05 }}
                    >
                      <div className="timeline-dot"></div>
                      <div className="timeline-content">
                        <div className="timeline-time">{activity.timestamp}</div>
                        <div className="timeline-browser">{activity.browser}</div>
                        <div className="timeline-title">{activity.title}</div>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="empty-state">
                    <Activity size={32} />
                    <p>No activity recorded yet</p>
                    <p>Start tracking to see browser activity</p>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  )
}

export default App