import { app, BrowserWindow, ipcMain } from 'electron';
import * as path from 'path';

// Real browser activity tracking
let mainWindow: BrowserWindow | null = null;
let isTracking = false;
let currentActivity = { browser: 'none', url: 'none', title: 'none' };

// Dynamic import for active-win ES module
async function getActiveWin() {
  try {
    // Use eval to prevent TypeScript from converting this to require()
    const importFn = new Function('specifier', 'return import(specifier)');
    const activeWinModule = await importFn('active-win');
    console.log('Active-win module imported successfully');
    
    // Use the correct function name
    return activeWinModule.activeWindow;
  } catch (error) {
    console.error('Failed to import active-win:', error);
    throw error;
  }
}

// Helper function to check if an app is a browser
function isBrowserWindow(appName: string): boolean {
  const browsers = ['chrome', 'firefox', 'edge', 'safari', 'brave', 'opera', 'vivaldi', 'arc'];
  return browsers.some(browser => 
    appName.toLowerCase().includes(browser)
  );
}

// Helper function to extract URL from browser window title
function extractUrlFromTitle(title: string, appName: string): string {
  // Common patterns in browser titles
  const urlPatterns = [
    /https?:\/\/[^\s\)]+/gi,  // Direct URL in title
    /([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}/gi  // Domain patterns
  ];
  
  for (const pattern of urlPatterns) {
    const match = title.match(pattern);
    if (match) {
      let url = match[0];
      if (!url.startsWith('http')) {
        url = `https://${url}`;
      }
      return url;
    }
  }
  
  // Fallback: try to guess from title and browser
  if (title.toLowerCase().includes('youtube')) return 'https://youtube.com';
  if (title.toLowerCase().includes('google')) return 'https://google.com';
  if (title.toLowerCase().includes('github')) return 'https://github.com';
  if (title.toLowerCase().includes('stackoverflow')) return 'https://stackoverflow.com';
  
  return `Active in ${appName}`;
}

// Real activity tracker using active-win
async function trackBrowserActivity() {
  if (!isTracking) {
    console.log('Tracking is disabled, skipping...');
    return;
  }
  
  console.log('Attempting to track browser activity...');
  
  try {
    const activeWinFn = await getActiveWin();
    const window = await activeWinFn();
    
    console.log('Active window detected:', window ? {
      title: window.title,
      owner: window.owner?.name,
      isBrowser: window.owner ? isBrowserWindow(window.owner.name) : false
    } : 'No window');
    
    if (window && window.owner && isBrowserWindow(window.owner.name)) {
      const browserName = window.owner.name;
      const windowTitle = window.title || 'Unknown Tab';
      const extractedUrl = extractUrlFromTitle(windowTitle, browserName);
      
      currentActivity = {
        browser: browserName,
        url: extractedUrl,
        title: windowTitle
      };
      
      console.log('Real browser activity detected:', currentActivity);
      
      // Send to renderer
      if (mainWindow) {
        mainWindow.webContents.send('activity-update', currentActivity);
      }
    } else if (window && window.owner) {
      // Non-browser window is active
      currentActivity = {
        browser: 'none',
        url: 'none',
        title: `${window.owner.name}: ${window.title || 'Unknown Window'}`
      };
      
      console.log('Non-browser activity detected:', currentActivity);
      
      // Send to renderer
      if (mainWindow) {
        mainWindow.webContents.send('activity-update', currentActivity);
      }
    }
  } catch (error) {
    console.error('Error tracking real activity:', error);
    // Fallback to previous activity or default
  }
  
  // Track every 3 seconds
  setTimeout(trackBrowserActivity, 3000);
}

function createMainWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    }
  });

  // Load the renderer
  if (process.env.NODE_ENV === 'development' || process.argv.includes('--dev')) {
    // Try different Vite ports
    const possiblePorts = [3000, 3001, 3002, 3003, 3004];
    let loaded = false;
    
    for (const port of possiblePorts) {
      try {
        mainWindow.loadURL(`http://localhost:${port}`);
        console.log(`Successfully loaded from port ${port}`);
        loaded = true;
        break;
      } catch (error) {
        console.log(`Failed to load from port ${port}, trying next...`);
      }
    }
    
    if (!loaded) {
      console.error('Failed to load from any Vite dev server port');
      // Fallback to production build if it exists
      try {
        mainWindow.loadFile(path.join(__dirname, '../dist/renderer/index.html'));
      } catch (fallbackError) {
        console.error('No fallback available:', fallbackError);
      }
    }
    
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
    isTracking = false;
  });

  console.log('Main window created');
}

// IPC handlers for simple activity tracking
ipcMain.handle('start-tracking', () => {
  isTracking = true;
  trackBrowserActivity();
  return 'Tracking started';
});

ipcMain.handle('stop-tracking', () => {
  isTracking = false;
  return 'Tracking stopped';
});

ipcMain.handle('get-current-activity', () => {
  return currentActivity;
});

// App lifecycle
app.whenReady().then(() => {
  createMainWindow();
  
  // Auto-start tracking when app is ready
  setTimeout(() => {
    isTracking = true;
    trackBrowserActivity();
    console.log('Auto-started browser activity tracking');
  }, 2000); // Wait 2 seconds for window to be ready
  
  console.log('App ready');
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createMainWindow();
  }
});