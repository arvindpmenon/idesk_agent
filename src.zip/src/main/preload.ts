import { contextBridge, ipcRenderer } from 'electron';

// Simple preload for browser activity tracking
contextBridge.exposeInMainWorld('electronAPI', {
  // Simple tracking controls
  startTracking: () => ipcRenderer.invoke('start-tracking'),
  stopTracking: () => ipcRenderer.invoke('stop-tracking'),
  getCurrentActivity: () => ipcRenderer.invoke('get-current-activity'),
  
  // Listen for activity updates
  onActivityUpdate: (callback: (data: any) => void) => {
    ipcRenderer.on('activity-update', (_event, data) => callback(data));
    
    // Return cleanup function
    return () => {
      ipcRenderer.removeAllListeners('activity-update');
    };
  }
});