# Tray Icons

This directory contains the system tray icons for the User Activity Monitor application.

## Required Icons

- `tray.png` - Default tray icon (16x16 for macOS, 32x32 for Windows/Linux)
- `tray-active.png` - Active monitoring tray icon (16x16 for macOS, 32x32 for Windows/Linux)

## Platform Requirements

### macOS
- 16x16 pixels
- PNG format
- Should be template images (black with alpha channel)
- Will be automatically inverted for dark menu bars

### Windows
- 16x16 or 32x32 pixels
- ICO or PNG format
- Should include multiple sizes in ICO files

### Linux
- 16x16 or 32x32 pixels
- PNG format
- Should follow system theme guidelines

## Creating Icons

For now, placeholder icons are created programmatically. In a production app, you should:

1. Create proper icon files using a graphics editor
2. Ensure they follow platform design guidelines
3. Test on all target platforms
4. Consider using electron-icon-builder for automated icon generation